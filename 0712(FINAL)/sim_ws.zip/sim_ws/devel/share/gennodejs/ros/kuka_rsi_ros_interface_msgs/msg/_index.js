
"use strict";

let KukaPose = require('./KukaPose.js');

module.exports = {
  KukaPose: KukaPose,
};
