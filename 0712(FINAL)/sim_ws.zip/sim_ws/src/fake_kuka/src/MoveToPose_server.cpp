#include "kuka_rsi_ros_interface_msgs/MoveToPose.h"
#include "ros/ros.h"
#include <unistd.h>

bool my_callback(kuka_rsi_ros_interface_msgs::MoveToPose::Request &request,
                 kuka_rsi_ros_interface_msgs::MoveToPose::Response &response)
{

  ROS_INFO("Received Goal point is (x,y,z,a,b,c) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
           request.pose.x, request.pose.y, request.pose.z, request.pose.a, request.pose.b, request.pose.c);

  ROS_INFO("The z position should be Positive");

  response.success = true;
  // ROS_INFO("Kuka is moving to the Pose...");
  // usleep(1000000);
  // ROS_INFO("Kuka is moving to the Pose...");
  // usleep(1000000);
  // ROS_INFO("Kuka is moving to the Pose...");
  // usleep(1000000);
  response.message = "Kuka has moved to the Pose";
  ROS_INFO("The z position is Positive:true");

  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "MoveToPose_server");
  ros::NodeHandle nh;

  ros::ServiceServer move_to_position_service =
      nh.advertiseService("move_to_position", my_callback);
  ROS_INFO("Service \"/move_to_position\" started.");
  ros::spin();

  return 0;
}
