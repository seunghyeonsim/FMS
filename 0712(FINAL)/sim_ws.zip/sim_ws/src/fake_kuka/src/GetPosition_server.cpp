#include "kuka_rsi_ros_interface_msgs/GetPose.h"
#include "ros/ros.h"

bool my_callback(kuka_rsi_ros_interface_msgs::GetPose::Request &request,
        kuka_rsi_ros_interface_msgs::GetPose::Response &response) {
    ROS_INFO("Position values request received.");
    //in mm, degree
    response.pose.x = 993.9;
    response.pose.y = -884.2;
    response.pose.z = 1634.7;
    response.pose.a = 135;
    response.pose.b = 0;
    response.pose.c = -180;

    ROS_INFO("Position sent");
    return true;
}

int main(int argc, char **argv) {
  ros::init(argc, argv, "GetPosition_server");
  ros::NodeHandle nh;


  ros::ServiceServer move_to_position_service =
            nh.advertiseService("get_position_values",my_callback);

  ROS_INFO("Service \"/get_position_values\" started.");
  ros::spin();

  return 0;
}