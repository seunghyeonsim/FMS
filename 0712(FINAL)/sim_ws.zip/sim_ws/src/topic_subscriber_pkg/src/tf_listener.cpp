#include <ros/ros.h>
#include <tf2_ros/transform_listener.h>
#include <geometry_msgs/TransformStamped.h>
#include <geometry_msgs/Twist.h>
// #include <turtlesim/Spawn.h>
struct Quaternion
{
    double w, x, y, z;
};

struct EulerAngle
{
    double roll, pitch, yaw;
};


struct Kuka_Pose
{
    double x, y, z, a, b, c;
};

EulerAngle quaternionToEuler(const Quaternion &q)
{
    EulerAngle euler;

    // roll (x-axis rotation)
    double sinr_cosp = 2.0 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1.0 - 2.0 * (q.x * q.x + q.y * q.y);
    euler.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2.0 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        euler.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        euler.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
    euler.yaw = std::atan2(siny_cosp, cosy_cosp);

    return euler;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "tf_listener");

    ros::NodeHandle node;

    tf2_ros::Buffer tfBuffer;
    tf2_ros::TransformListener tfListener(tfBuffer);

    ros::Rate rate(10.0);
    while (node.ok())
    {
        geometry_msgs::TransformStamped transformStamped;
        try
        {
            transformStamped = tfBuffer.lookupTransform("Kuka", "Goal_o",
                                                        ros::Time(0));
        }
        catch (tf2::TransformException &ex)
        {
            ROS_WARN("%s", ex.what());
            ros::Duration(1.0).sleep();
            continue;
        }

        double x_o = transformStamped.transform.translation.x;
        double y_o = transformStamped.transform.translation.y;
        double z_o = transformStamped.transform.translation.z;
        double q_x_o = transformStamped.transform.rotation.x;
        double q_y_o = transformStamped.transform.rotation.y;
        double q_z_o = transformStamped.transform.rotation.z;
        double q_w_o = transformStamped.transform.rotation.w;
        ROS_INFO("Goal position from kuka (meter and quaternion)(x,y,z,q_x,q_y,q_z,q_w) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                 x_o, y_o, z_o, q_x_o, q_y_o, q_z_o, q_w_o);

        Quaternion quaternion = {q_w_o, q_x_o, q_y_o, q_z_o}; // Example quaternion (w, x, y, z) (0.70710678, 0.0, 0.0, 0.70710678) representing 45 degrees rotation around the z-axis
        EulerAngle euler = quaternionToEuler(quaternion);
        // m -> mm & rad -> deg
        Kuka_Pose G_k = {x_o*1000, y_o*1000, z_o*1000, euler.yaw* 180.0 / M_PI, euler.pitch* 180.0 / M_PI, euler.roll* 180.0 / M_PI};

        ROS_INFO("Goal Pose_for kuka (mm & degree) (x,y,z,a,b,c)_k =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                     G_k.x, G_k.y, G_k.z, G_k.a, G_k.b, G_k.c);

        rate.sleep();
    }
    return 0;
};