#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <kuka_rsi_ros_interface_msgs/KukaPose.h>

int main(int argc, char** argv) {

    ros::init(argc, argv, "kuka_pub");
    ros::NodeHandle nh;
    
    ros::Publisher pub = nh.advertise<kuka_rsi_ros_interface_msgs::KukaPose>("kuka_pose", 1000);
    ros::Rate loop_rate(2);
    
    kuka_rsi_ros_interface_msgs::KukaPose kuka_pose;
    kuka_pose.x = 5;
    kuka_pose.y = 10;
    kuka_pose.z = 21;
    kuka_pose.a = 5;
    kuka_pose.b = 10;
    kuka_pose.c = 21;

    
    while (ros::ok())
    {
        pub.publish(kuka_pose);
        ros::spinOnce();
        loop_rate.sleep();
    }
    
    return 0;
}
