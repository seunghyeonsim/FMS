#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/PoseStamped.h>
#include "kuka_rsi_ros_interface_msgs/MoveToPose.h"
#include "kuka_rsi_ros_interface_msgs/GetPose.h"
#include <iostream>
#include <cmath>
#include <Eigen/Dense>
#include <vector>

struct Quaternion
{
    double w, x, y, z;
};

struct EulerAngle
{
    double roll, pitch, yaw;
};

struct Kuka_Pose
{
    double x, y, z, a, b, c;
};

EulerAngle quaternionToEuler(const Quaternion &q)
{
    EulerAngle euler;

    // roll (x-axis rotation)
    double sinr_cosp = 2.0 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1.0 - 2.0 * (q.x * q.x + q.y * q.y);
    euler.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2.0 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        euler.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        euler.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
    euler.yaw = std::atan2(siny_cosp, cosy_cosp);

    return euler;
}

Eigen::Matrix4f computeTransformMatrix(float x, float y, float z, float a, float b, float c,  float d_x, float d_y, float d_z,float d_yaw,float d_pitch, float d_roll)
{
    // unit : mm & radian
    // d_theta is from parameter. d_x y z are from parameters too.
    // x,y,z,a,b,c from the opti track
    float a_C = a;
    float a_B = b;
    float a_A = c;
    // Convert to radians
    float d_yaw_rad = d_yaw * M_PI / 180.0;
    float d_pitch_rad = d_pitch * M_PI / 180.0;
    float d_roll_rad = d_roll * M_PI / 180.0;

    // ZYX rotation matrix Toe
    Eigen::Matrix4f Toe;
    Toe << cos(a_C) * cos(a_B), -sin(a_C) * cos(a_A) + cos(a_C) * sin(a_B) * sin(a_A), sin(a_C) * sin(a_A) + cos(a_C) * sin(a_B) * cos(a_A), x*1000,
        sin(a_C) * cos(a_B), cos(a_C) * cos(a_A) + sin(a_C) * sin(a_B) * sin(a_A), -cos(a_C) * sin(a_A) + sin(a_C) * sin(a_B) * cos(a_A), y*1000,
        -sin(a_B), cos(a_B) * sin(a_A), cos(a_B) * cos(a_A), z*1000,
        0, 0, 0, 1;

    // // Transform matrix Tko
    // Eigen::Matrix4f Tko;
    // Tko << cos(d_theta_rad), -sin(d_theta_rad), 0, d_x,
    //     sin(d_theta_rad), cos(d_theta_rad), 0, d_y,
    //     0, 0, 1, d_z,
    //     0, 0, 0, 1;
    Eigen::Matrix4f Tko;
    Tko << cos(d_yaw_rad) * cos(d_pitch_rad), -sin(d_yaw_rad) * cos(d_roll_rad) + cos(d_yaw_rad) * sin(d_pitch_rad) * sin(d_roll_rad), sin(d_yaw_rad) * sin(d_roll_rad) + cos(d_yaw_rad) * sin(d_pitch_rad) * cos(d_roll_rad), x*1000,
        sin(d_yaw_rad) * cos(d_pitch_rad), cos(d_yaw_rad) * cos(d_roll_rad) + sin(d_yaw_rad) * sin(d_pitch_rad) * sin(d_roll_rad), -cos(d_yaw_rad) * sin(d_roll_rad) + sin(d_yaw_rad) * sin(d_pitch_rad) * cos(d_roll_rad), y*1000,
        -sin(d_pitch_rad), cos(d_pitch_rad) * sin(d_roll_rad), cos(d_pitch_rad) * cos(d_roll_rad), z*1000,
        0, 0, 0, 1;

    // Total transform matrix Tke
    Eigen::Matrix4f Tke = Tko * Toe;

    return Tke;
}

Eigen::Vector3f extractEulerAngles(const Eigen::Matrix4f &transformMatrix)
{
    Eigen::Vector3f euler_angles;

    // Roll (X-axis rotation)
    euler_angles(0) = atan2(transformMatrix(2, 1), transformMatrix(2, 2));

    // Pitch (Y-axis rotation)
    euler_angles(1) = atan2(-transformMatrix(2, 0), sqrt(transformMatrix(2, 1) * transformMatrix(2, 1) + transformMatrix(2, 2) * transformMatrix(2, 2)));

    // Yaw (Z-axis rotation)
    euler_angles(2) = atan2(transformMatrix(1, 0), transformMatrix(0, 0));

    return euler_angles;
}

std::vector<std::vector<double>> calculateTrajectory(const std::vector<double> &thetastart,
                                                     const std::vector<double> &thetaend,
                                                     double Tf,
                                                     int N,
                                                     int method)
{
    double timegap = Tf / (N - 1);
    std::vector<std::vector<double>> traj(N, std::vector<double>(thetastart.size(), 0));

    for (int i = 0; i < N; i++)
    {
        double t = timegap * i;
        double s;

        if (method == 3)
        {
            s = 3 * std::pow(t / Tf, 2) - 2 * std::pow(t / Tf, 3);
        }
        else
        {
            s = 10 * std::pow(t / Tf, 3) - 15 * std::pow(t / Tf, 4) + 6 * std::pow(t / Tf, 5);
        }

        for (size_t j = 0; j < thetastart.size(); j++)
        {
            traj[i][j] = thetastart[j] + s * (thetaend[j] - thetastart[j]);
        }
    }

    return traj;
}

class SubscribeAndCall
{
public:
    SubscribeAndCall()
    {
        // Services you want to Call
        move_to_position_service = nh.serviceClient<kuka_rsi_ros_interface_msgs::MoveToPose>("/move_to_position");
        get_position_service = nh.serviceClient<kuka_rsi_ros_interface_msgs::GetPose>("/get_position_values");
        // Topic you want to subscribe
        // sub = nh.subscribe("/natnet_ros/RigidBody_goal/pose", 1, &SubscribeAndCall::callback, this);
        sub = nh.subscribe("fake_goal_pose", 1, &SubscribeAndCall::callback, this);
    }

    void callback(const geometry_msgs::PoseStamped::ConstPtr &msg)
    {
        // Call GetPose service to get a initial pose
        kuka_rsi_ros_interface_msgs::GetPose pose;
        if (get_position_service.call(pose)) // Send through the connection the name of the trajectory to execute
        {
            double x_ik = pose.response.pose.x;
            double y_ik = pose.response.pose.y;
            double z_ik = pose.response.pose.z;
            double a_ik = pose.response.pose.a;
            double b_ik = pose.response.pose.b;
            double c_ik = pose.response.pose.c;
            Kuka_Pose I_k = {x_ik, y_ik, z_ik, a_ik, b_ik, c_ik};
            ROS_INFO("Initial pose of the end effecter( kuka frame (mm,deg)) (x,y,z,a,b,c) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                     I_k.x, I_k.y, I_k.z, I_k.a, I_k.b, I_k.c);
            // Get parameter from the launch file
            double delta_x, delta_y, delta_z, delta_yaw, delta_pitch, delta_roll;
            ros::param::get("/delta_x", delta_x);
            ros::param::get("/delta_y", delta_y);
            ros::param::get("/delta_z", delta_z);
            ros::param::get("/delta_yaw", delta_yaw);
            ros::param::get("/delta_pitch", delta_pitch);
            ros::param::get("/delta_roll", delta_roll);

            ROS_INFO("Received parameter delta(x,y,z,theta)=%.3f,%.3f,%.3f,%.3f",
                     delta_x, delta_y, delta_z, delta_yaw,delta_pitch,delta_roll);

            double x_o = msg->pose.position.x;
            double y_o = msg->pose.position.y;
            double z_o = msg->pose.position.z;
            double q_x_o = msg->pose.orientation.x;
            double q_y_o = msg->pose.orientation.y;
            double q_z_o = msg->pose.orientation.z;
            double q_w_o = msg->pose.orientation.w;
            ROS_INFO("Goal position from opti track (meter and quaternion)(x,y,z,q_x,q_y,q_z,q_w) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                     x_o, y_o, z_o, q_x_o, q_y_o, q_z_o, q_w_o);
            // need to convert G_o = (x,y,z,a,b,c,d) to G_k = (x,y,z,a,b,c) with the parameter (delta_x,y,z,a,b,c)

            // 1. quaternion to euler

            Quaternion quaternion = {q_w_o, q_x_o, q_y_o, q_z_o}; // Example quaternion (w, x, y, z) (0.70710678, 0.0, 0.0, 0.70710678) representing 45 degrees rotation around the z-axis
            EulerAngle euler = quaternionToEuler(quaternion);
            Kuka_Pose G_o = {x_o, y_o, z_o, euler.yaw, euler.pitch, euler.roll};
            ROS_INFO("Goal position from opti track (mm and euler(radian))(x,y,z,a,b,c) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                     x_o, y_o, z_o, euler.yaw, euler.pitch, euler.roll);
            // unit : meter & radian
            //  2. transfer matrix : G_o ->G_k
            //  Compute T_ke : end effecter pose from the kuka base frame
            Eigen::Matrix4f transformMatrix_k = computeTransformMatrix(G_o.x, G_o.y, G_o.z, G_o.a, G_o.b, G_o.c, delta_x, delta_y, delta_z,delta_yaw,delta_pitch,delta_roll);

            // Extract euler angles from the transformation matrix
            Eigen::Vector3f euler_angles = extractEulerAngles(transformMatrix_k);
            // transform matrix to vector
            //  output of the angles : radian, mm -> mm & degree
            double x_k = transformMatrix_k(0, 3) ;
            double y_k = transformMatrix_k(1, 3) ;
            double z_k = transformMatrix_k(2, 3) +100;
            double a_k = euler_angles(2) * 180.0 / M_PI;
            double b_k = euler_angles(1) * 180.0 / M_PI;
            double c_k = euler_angles(0) * 180.0 / M_PI;
            Kuka_Pose G_k = {x_k, y_k, z_k, a_k, b_k, c_k};
            ROS_INFO("Goal Pose_for kuka (mm & degree) (x,y,z,a,b,c)_k =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
                     G_k.x, G_k.y, G_k.z, G_k.a, G_k.b, G_k.c);

            /////////Trajectory Generation

            std::vector<double> thetastart = {I_k.x, I_k.y, I_k.z, I_k.a, I_k.b, I_k.c};
            std::vector<double> thetaend = {G_k.x, G_k.y, G_k.z, G_k.a, G_k.b, G_k.c};

            // Get parameter from the launch file
            double Tf;
            int N,method;
            ros::param::get("/Tf", Tf);
            ros::param::get("/N", N);
            ros::param::get("/method", method);

            ROS_INFO("Received parameter delta meter & degree (Tf,N,method)=%.3f,%d,%d",
                     Tf, N, method);

            std::vector<std::vector<double>> traj = calculateTrajectory(thetastart, thetaend, Tf, N, method);
            double x, y, z, a, b, c;
            ROS_INFO("Trajectory from the Initial pose to the Goal pose has generated.");
            for (int i = 1; i < N; i++) //int i=1 is the initial pose
            {

                std::cout << '[' << traj[i][0] << ',' << traj[i][1] << ',' << traj[i][2] << ',' << traj[i][3] << ',' << traj[i][4] << ',' << traj[i][5] << ']' << std::endl;
                ;
                // call the service [MoveToPose]///////////////////////////////////////////////////////////////////////////////////////////////


                kuka_rsi_ros_interface_msgs::MoveToPose srv;
                srv.request.pose.x = traj[i][0];
                srv.request.pose.y = traj[i][1];
                srv.request.pose.z = traj[i][2];
                srv.request.pose.a = traj[i][3];
                srv.request.pose.b = traj[i][4];
                srv.request.pose.c = traj[i][5];

                if (move_to_position_service.call(srv)) // Send through the connection the name of the trajectory to execute
                {
                    ROS_INFO("%s", srv.response.message.c_str()); // Print the result given by the service called
                    
                }
                else
                {
                    ROS_ERROR("Failed to call service /move_to_position");
                }
                



                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            }
            ROS_INFO("Kuka has moved to the Goal pose");
            ros::shutdown();
        }
        else
        {
            ROS_ERROR("Failed to call service /get_position_values");
            ros::shutdown();
        }
    }

private:
    ros::NodeHandle nh;
    ros::Subscriber sub;
    ros::ServiceClient move_to_position_service;
    ros::ServiceClient get_position_service;
}; // End of class SubscribeAndCall

int main(int argc, char **argv)
{

    // Initiate ROS
    ros::init(argc, argv, "get_topic_srv_client");

    // Create an object of class SubscribeAndCall that will take care of everything
    SubscribeAndCall SACbject;

    ros::spin();

    return 0;
}