#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/PoseStamped.h>

double x_current = 0;

void counterCallback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    ROS_INFO_STREAM("Received pose: " << msg);
    x_current = msg->pose.position.x;
    double x_o = msg->pose.position.x;
    double y_o = msg->pose.position.y;
    double z_o = msg->pose.position.z;
    double q_x_o = msg->pose.orientation.x;
    double q_y_o = msg->pose.orientation.y;
    double q_z_o = msg->pose.orientation.z;
    double q_w_o = msg->pose.orientation.w;
    ROS_INFO("Goal position from opti track (m and quaternion)(x,y,z,q_x,q_y,q_z,q_w) =%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
             x_o, y_o, z_o, q_x_o, q_y_o, q_z_o, q_w_o);
}
int main(int argc, char **argv)
{

    ros::init(argc, argv, "motive_sub");
    ros::NodeHandle nh;

    ros::Subscriber sub = nh.subscribe("/natnet_ros/RigidBody_goal/pose", 1, counterCallback);

    ros::spin();

    return 0;
}
