#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/PoseStamped.h>
#include <kuka_rsi_ros_interface_msgs/KukaPose.h>

class SubscribeAndPublish
{
public:
  SubscribeAndPublish()
  {
    //Topic you want to publish
    pub = nh.advertise<kuka_rsi_ros_interface_msgs::KukaPose>("kuka_pose", 1000);

    //Topic you want to subscribe
    sub = nh.subscribe("fake_goal_pose", 1000, &SubscribeAndPublish::callback, this);
  }

  void callback(const geometry_msgs::PoseStamped::ConstPtr& msg)
  {
    double x_current = 0;
    ROS_INFO_STREAM("Received pose: " << msg);
    x_current = msg->pose.position.x;
    ROS_INFO_STREAM(x_current);



    kuka_rsi_ros_interface_msgs::KukaPose kuka_pose;
    //.... do something with the input and generate the output...
    kuka_pose.x = msg->pose.position.x;
    kuka_pose.y = msg->pose.position.y;
    kuka_pose.z = msg->pose.position.z;
    kuka_pose.a = msg->pose.position.x;
    kuka_pose.b = msg->pose.position.x;
    kuka_pose.c = msg->pose.position.x;
    pub.publish(kuka_pose);
  }

private:
  ros::NodeHandle nh; 
  ros::Publisher pub;
  ros::Subscriber sub;

};//End of class SubscribeAndPublish

int main(int argc, char **argv)
{
  //Initiate ROS
  ros::init(argc, argv, "motive2kuka");

  //Create an object of class SubscribeAndPublish that will take care of everything
  SubscribeAndPublish SAPObject;

  ros::spin();

  return 0;
}
