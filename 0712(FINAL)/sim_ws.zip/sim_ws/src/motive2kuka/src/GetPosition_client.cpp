#include "ros/ros.h"
#include "kuka_rsi_ros_interface_msgs/GetPose.h"
// Import the service message used by the service /get_position_values

int main(int argc, char **argv)
{
  ros::init(argc, argv, "GetPosition_client"); // Initialise a ROS node with the name service_client
  ros::NodeHandle nh;

  // Create the connection to the service /get_position_values
  ros::ServiceClient get_position_service = nh.serviceClient<kuka_rsi_ros_interface_msgs::GetPose>("/get_position_values");
  kuka_rsi_ros_interface_msgs::GetPose srv; // Create an object of type GetPosition
  

  if (get_position_service.call(srv)) // Send through the connection the name of the trajectory to execute
  {

    ROS_INFO("Kuka x point is =%f", srv.response.pose.x);
    ROS_INFO("Kuka y point is =%f", srv.response.pose.y);
    ROS_INFO("Kuka z point is =%f", srv.response.pose.z);
    ROS_INFO("Kuka a point is =%f", srv.response.pose.a);
    ROS_INFO("Kuka b point is =%f", srv.response.pose.b);
    ROS_INFO("Kuka c point is =%f", srv.response.pose.c);
  }
  else
  {
    ROS_ERROR("Failed to call service /get_position_values");
    return 1;
  }

  return 0;
}
