#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/PoseStamped.h>

int main(int argc, char** argv) {

    ros::init(argc, argv, "fake_pose_publisher");
    ros::NodeHandle nh;
    
    ros::Publisher pub = nh.advertise<geometry_msgs::PoseStamped>("fake_goal_pose", 1000);
    ros::Rate loop_rate(2);
    
    geometry_msgs::PoseStamped fake_pose;

    fake_pose.pose.position.x = 0.2046;
    fake_pose.pose.position.y = 0.8474;
    fake_pose.pose.position.z = -0.4832;
    fake_pose.pose.orientation.x = 0.18257;
    fake_pose.pose.orientation.y = 0.674518;
    fake_pose.pose.orientation.z = 0.039613;
    fake_pose.pose.orientation.w = -0.73696;
    
    while (ros::ok())
    {
        pub.publish(fake_pose);
        ros::spinOnce();
        loop_rate.sleep();

    }
    
    return 0;
}

