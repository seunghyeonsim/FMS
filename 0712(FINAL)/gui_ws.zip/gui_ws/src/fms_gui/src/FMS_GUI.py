#!/usr/bin/env python3


import os
import subprocess
import time
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import messagebox


#Functions for Frame 1 
#Check_button_1 이 눌러 졌을 때 실행하는 것
def check_button_1_clicked():
    launch_file_path="/home/kiros/sim_ws/src/fake_opti_track/launch/fake_opti_track_launch.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)
    flag = 1
    ''' IF 문 조건 수정 필요 RSSI Stream Check '''
    if flag == 1:
        label1['text']  = 'Motive ON'
        #Button 수정 "
        buttons[0].config(state=tk.DISABLED)
        buttons[1].config(state=tk.NORMAL)
        #.showinfo("Message", "RSSI Signal is connected")  
    else:
        messagebox.showinfo("Error Message", "RSSI Signal is not sent") 

def check_button_2_clicked():
    launch_file_path="/home/kiros/sim_ws/src/fake_kuka/launch/fake_kuka.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)
    flag = 1
    ''' IF 문 조건 수정 필요 / Motive Stream Check'''
    if flag == 1:
        label2['text']  = 'KUKA RSI ON'
        #Button 수정 
        buttons[1].config(state=tk.DISABLED)
        buttons[2].config(state=tk.NORMAL)
        #messagebox.showinfo("Message", "RSSI Signal is connected")  
    else:
        messagebox.showinfo("Error Message", "Motive Stream is Unabled") 
        
def start_stream_button_clicked():
    #launch streaming signal showing
    buttons[3].config(state=tk.NORMAL)
    buttons[4].config(state=tk.NORMAL)
    
    #Calibration_parameter 초기화
    textbox1.delete(0, tk.END)
    textbox2.delete(0, tk.END)
    textbox3.delete(0, tk.END)
    textbox1.insert(0, "0.0")
    textbox2.insert(0, "0.0")
    textbox3.insert(0, "0.0")
    
#Functions for Frame 2 
def MoveToGoalPosition():
    launch_file_path="/home/kiros/sim_ws/src/motive2kuka/launch/get_topic_srv_client_using_TF.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)

    for i in range(1,101):
        time.sleep(0.01)
        pre_progress_var.set(i)
        progress_bar.update()

        
#import rospy

# Tkinter 윈도우 생성
window = tk.Tk()
window.title("Control Loop")
window.geometry('600x500+10+10')
#window.iconbitmap('/home/kiros/catkin_ws/p_icon.ico')

'''GUI 구성'''
# 상단 부 Name 라벨 생성
label0 = tk.Label(window, text="Flexible Manufacturing System", font=('Times', 20), pady=10)
label0.pack()

# 버튼 생성
buttons = []
Robot_Pos_Labels = []

#Frame 1 생성
frame1 = tk.LabelFrame(text='Environment Setting',width = 500, height = 200, relief = 'sunken', bd=2)
frame1.place(x=50,y=50)
#Button 생성


# launch_button = tk.Button(frame1, text="Start Motive Streaming",
#                           command=check_button_1_clicked(), state=tk.DISABLED,bg='#ffb3fe', width=30)
# launch_button.pack()

check_button_1 = tk.Button(frame1, text="Start Motive Streaming", command=check_button_1_clicked, state=tk.DISABLED, bg='#ffb3fe', width=30)
check_button_1.pack(pady = 13)
buttons.append(check_button_1)
check_button_2 = tk.Button(frame1, text="Start KUKA RSI", command = check_button_2_clicked, state=tk.DISABLED, bg='#ffb3fe', width = 30)
check_button_2.pack(pady = 13)
buttons.append(check_button_2)








#Frame 2 생성
frame2 = tk.LabelFrame(text='Display', width = 200, height = 150, relief = 'sunken', bd=2)
frame2.place(x=300,y=50)
label1 = tk.Label(frame2, text="")#RSSI OK
label1.place(x=0,y=15,width = 110)
label2 = tk.Label(frame2, text="",justify='left')#Motive Stream OK
label2.place(x=0,y=70,width = 110)

#label.grid(row=0, column = 0)

#Frame 3 생성
frame3 = tk.LabelFrame(text='Main Process', width = 450, height = 200, relief = 'sunken', bd=2)
frame3.place(x=50,y=200)
process_button_1 = tk.Button(frame3, text="Get KUKA Position", command = start_stream_button_clicked, state=tk.DISABLED, bg='#ffb3fe', width = 50, pady = 5)
process_button_1.pack(pady = 10)
buttons.append(process_button_1)
process_button_2 = tk.Button(frame3, text="Move To Goal Position", command = MoveToGoalPosition, state=tk.DISABLED, bg='#ffb3fe', width = 50, pady = 5)
process_button_2.pack(pady = 10)
buttons.append(process_button_2)

# 변수 Variable Define 
delta_x = tk.StringVar()
delta_y = tk.StringVar()
delta_z = tk.StringVar()
#delta_y.set("1.0")
#delta_x.set("1.0")
#delta_z.set("1.0")

#Frame 4 생성
# frame4 = tk.LabelFrame(text='Calibration', width = 500, height = 200, relief = 'solid', bd=2)
# frame4.place(x=425,y=200)
# textbox1 = tk.Entry(frame4, width=10, textvariable = delta_x)
# textbox1.grid(row=1, column=1, pady=(10, 10))
# textbox2 = tk.Entry(frame4, width=10, textvariable = delta_y)
# textbox2.grid(row=2, column=1, pady=(0, 10))
# textbox3 = tk.Entry(frame4, width=10, textvariable = delta_z)
# textbox3.grid(row=3, column=1, pady=(0, 10))

# 첫 번째 버튼 활성화
buttons[0].config(state=tk.NORMAL)

#Frame 5 생성
frame5 = tk.LabelFrame(text='Progress Statement', width = 450, height = 140, relief = 'sunken', bd=2)
frame5.place(x=50, y=350)
pre_progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(frame5, maximum = 100, length = 400, variable = pre_progress_var)
progress_bar.place(x=10, y=10)
f5_label1 = tk.Label(frame5, text="Robot Position")
f5_label1.place(x=10,y=40,width = 100)
f5_r_label1 = tk.Label(frame5, text="X:")
f5_r_label1.place(x=10,y=60,width = 50)
Robot_Pos_Labels.append(f5_r_label1)
f5_r_label2 = tk.Label(frame5, text="Y:")
f5_r_label2.place(x=10,y=80,width = 50)
Robot_Pos_Labels.append(f5_r_label2)
f5_r_label3 = tk.Label(frame5, text="Z:")
f5_r_label3.place(x=10,y=100,width = 50)
Robot_Pos_Labels.append(f5_r_label3)


# 이벤트 루프 시작
window.mainloop()
