#! /usr/bin/env python3

#ROS
import rospy
from kuka_rsi_ros_interface_msgs.srv import GetPose
#Tkinter
import os
import subprocess
import time
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import messagebox


#################################################################################################
#################################ROS#############################################################


def get_position_client():
    rospy.init_node('GetPosition_client')  # Initialize a ROS node with the name "GetPosition_client"
    rospy.wait_for_service('/get_position_values')  # Wait for the service to become available

    try:
        # Create a handle to the service
        get_position_service = rospy.ServiceProxy('/get_position_values', GetPose)

        # Call the service
        response = get_position_service()

        # Process the response
        pose = response.pose
        pose_list = [f'{pose.x}', f'{pose.y}', f'{pose.z}', f'{pose.a}', f'{pose.b}', f'{pose.c}']
        rospy.loginfo("Kuka x point is: %f", pose.x)
        rospy.loginfo("Kuka y point is: %f", pose.y)
        rospy.loginfo("Kuka z point is: %f", pose.z)
        rospy.loginfo("Kuka a point is: %f", pose.a)
        rospy.loginfo("Kuka b point is: %f", pose.b)
        rospy.loginfo("Kuka c point is: %f", pose.c)

        return pose_list

    except rospy.ServiceException as e:
        rospy.logerr("Failed to call service /get_position_values: %s", str(e))


#################################################################################################
#################################TKINTER#########################################################

#Functions for Frame 1 
#Check_button_1 이 눌러 졌을 때 실행하는 것
def check_button_1_clicked():
    launch_file_path="/home/kiros/sim_ws/src/natnet_ros_cpp/launch/natnet_ros.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)
    flag = 1
    ''' IF 문 조건 수정 필요 RSSI Stream Check '''
    if flag == 1:
        label1['text']  = 'Motive ON'
        #Button 수정 "
        buttons[0].config(state=tk.DISABLED)
        buttons[1].config(state=tk.NORMAL)
        #.showinfo("Message", "RSSI Signal is connected")  
    else:
        messagebox.showinfo("Error Message", "RSSI Signal is not sent") 

def check_button_2_clicked():
    launch_file_path="/home/kiros/sim_ws/src/kuka_rsi_ros_interface/kuka_rsi_ros_interface_core/launch/start.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)
    flag = 1
    ''' IF 문 조건 수정 필요 / Motive Stream Check'''
    if flag == 1:
        label2['text']  = 'KUKA RSI ON'
        #Button 수정 
        buttons[1].config(state=tk.DISABLED)
        buttons[2].config(state=tk.NORMAL)
        messagebox.showinfo("INFO", "Start KUKA Controller") 
        #messagebox.showinfo("Message", "RSSI Signal is connected")  
    else:
        messagebox.showinfo("Error Message", "Motive Stream is Unabled") 
        
def Get_KUKA_POSITION():
    returned_pose_list = get_position_client()

    # Print the pose_list
    print("Pose list:", returned_pose_list)
    flag = 1
    ''' IF 문 조건 수정 필요 / Motive Stream Check'''
    if flag == 1:
        f5_r_label1['text']  = returned_pose_list[0]
        f5_r_label2['text']  = returned_pose_list[1]
        f5_r_label3['text']  = returned_pose_list[2]
        f5_r_label4['text']  = returned_pose_list[3]
        f5_r_label5['text']  = returned_pose_list[4]
        f5_r_label6['text']  = returned_pose_list[5]

        #Button 수정 
        buttons[3].config(state=tk.NORMAL)
        #messagebox.showinfo("Message", "RSSI Signal is connected")  
    else:
        messagebox.showinfo("Error Message", "Motive Stream is Unabled") 
    
#Functions for Frame 2 
def MoveToGoalPosition():
    launch_file_path="/home/kiros/sim_ws/src/motive2kuka/launch/get_topic_srv_client_using_TF.launch"
    command = f"gnome-terminal -- roslaunch {launch_file_path}"
    subprocess.Popen(command, shell=True)

    for i in range(1,101):
        time.sleep(0.01)
        pre_progress_var.set(i)
        progress_bar.update()


# Tkinter 윈도우 생성
window = tk.Tk()
window.config(background='#fffdd0')
window.title("Control Loop")
window.geometry('600x700+10+10')
#window.iconbitmap('/home/kiros/catkin_ws/p_icon.ico')

'''GUI 구성'''
# 상단 부 Name 라벨 생성
label0 = tk.Label(window, text="Flexible Manufacturing System", font=('Times', 20), pady=10)
label0.config(background='#fffdd0')
label0.pack()

# 버튼 생성
buttons = []
Robot_Pos_Labels = []

#Frame 1 생성
frame1 = tk.LabelFrame(text='Environment Setting',width = 500, height = 200, relief = 'sunken', bd=2)
frame1.config(background='#fffdd0')
frame1.place(x=50,y=50)
#Button 생성


# launch_button = tk.Button(frame1, text="Start Motive Streaming",
#                           command=check_button_1_clicked(), state=tk.DISABLED,bg='#ffb3fe', width=30)
# launch_button.pack()

check_button_1 = tk.Button(frame1, text="Start Motive Streaming", command=check_button_1_clicked, state=tk.DISABLED, bg='#ffa500', width=30)
check_button_1.pack(pady = 13)
buttons.append(check_button_1)
check_button_2 = tk.Button(frame1, text="Start KUKA RSI", command = check_button_2_clicked, state=tk.DISABLED, bg='#ffa500', width = 30)
check_button_2.pack(pady = 13)
buttons.append(check_button_2)








#Frame 2 생성
frame2 = tk.LabelFrame(text='Display', width = 200, height = 150, relief = 'sunken', bd=2)
frame2.place(x=300,y=50)
frame2.config(background='#fffdd0')
label1 = tk.Label(frame2, text="")#RSSI OK
label1.config(background='#fffdd0')
label1.place(x=0,y=15,width = 110)
label2 = tk.Label(frame2, text="",justify='left')#Motive Stream OK
label2.config(background='#fffdd0')
label2.place(x=0,y=70,width = 110)

#label.grid(row=0, column = 0)

#Frame 3 생성
frame3 = tk.LabelFrame(text='Main Process', width = 450, height = 200, relief = 'sunken', bd=2)
frame3.place(x=50,y=200)
frame3.config(background='#fffdd0')
process_button_1 = tk.Button(frame3, text="Get KUKA Position", command = Get_KUKA_POSITION, state=tk.DISABLED, bg='#ffa500', width = 50, pady = 5)
process_button_1.pack(pady = 10)
buttons.append(process_button_1)
process_button_2 = tk.Button(frame3, text="Move To Goal Position", command = MoveToGoalPosition, state=tk.DISABLED, bg='#ffa500', width = 50, pady = 5)
process_button_2.pack(pady = 10)
buttons.append(process_button_2)

# 변수 Variable Define 
# delta_x = tk.StringVar()
# delta_y = tk.StringVar()
# delta_z = tk.StringVar()
#delta_y.set("1.0")
#delta_x.set("1.0")
#delta_z.set("1.0")

#Frame 4 생성
# frame4 = tk.LabelFrame(text='Calibration', width = 500, height = 200, relief = 'solid', bd=2)
# frame4.place(x=425,y=200)
# textbox1 = tk.Entry(frame4, width=10, textvariable = delta_x)
# textbox1.grid(row=1, column=1, pady=(10, 10))
# textbox2 = tk.Entry(frame4, width=10, textvariable = delta_y)
# textbox2.grid(row=2, column=1, pady=(0, 10))
# textbox3 = tk.Entry(frame4, width=10, textvariable = delta_z)
# textbox3.grid(row=3, column=1, pady=(0, 10))

# 첫 번째 버튼 활성화
buttons[0].config(state=tk.NORMAL)

#Frame 5 생성
frame5 = tk.LabelFrame(text='Progress Statement', width = 450, height = 260, relief = 'sunken', bd=2)
frame5.place(x=50, y=380)
frame5.config(background='#fffdd0')


f5_label1 = tk.Label(frame5, text="Robot Position")
f5_label1.place(x=10,y=10,width = 100)
f5_label1.config(background='#fffdd0')
f5_r_labelx = tk.Label(frame5, text="X:", justify='left')
f5_r_labelx.place(x=10,y=30,width = 20)
f5_r_labelx.config(background='#fffdd0')
f5_r_labely = tk.Label(frame5, text="Y:", justify='left')
f5_r_labely.place(x=10,y=50,width = 20)
f5_r_labely.config(background='#fffdd0')
f5_r_labelz = tk.Label(frame5, text="Z:", justify='left')
f5_r_labelz.place(x=10,y=70,width = 20)
f5_r_labelz.config(background='#fffdd0')
f5_r_labela = tk.Label(frame5, text="A:", justify='left')
f5_r_labela.place(x=10,y=90,width = 20)
f5_r_labela.config(background='#fffdd0')
f5_r_labelb = tk.Label(frame5, text="B:", justify='left')
f5_r_labelb.place(x=10,y=110,width = 20)
f5_r_labelb.config(background='#fffdd0')
f5_r_labelc = tk.Label(frame5, text="C:", justify='left')
f5_r_labelc.place(x=10,y=130,width = 20)
f5_r_labelc.config(background='#fffdd0')

f5_r_label1 = tk.Label(frame5, text="", justify='right')
f5_r_label1.place(x=30,y=30,width = 120)
f5_r_label1.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label1)
f5_r_label2 = tk.Label(frame5, text="", justify='right')
f5_r_label2.place(x=30,y=50,width = 120)
f5_r_label2.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label2)
f5_r_label3 = tk.Label(frame5, text="", justify='right')
f5_r_label3.place(x=30,y=70,width = 120)
f5_r_label3.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label3)
f5_r_label4 = tk.Label(frame5, text="", justify='right')
f5_r_label4.place(x=30,y=90,width = 120)
f5_r_label4.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label1)
f5_r_label5 = tk.Label(frame5, text="", justify='right')
f5_r_label5.place(x=30,y=110,width = 120)
f5_r_label5.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label2)
f5_r_label6 = tk.Label(frame5, text="", justify='right')
f5_r_label6.place(x=30,y=130,width = 120)
f5_r_label6.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label3)

f5_r_label7 = tk.Label(frame5, text="Move To The Goal", justify='right')
f5_r_label7.place(x=10,y=170,width = 120)
f5_r_label7.config(background='#fffdd0')
Robot_Pos_Labels.append(f5_r_label3)
pre_progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(frame5, maximum = 100, length = 400, variable = pre_progress_var)
progress_bar.place(x=10, y=200)


if __name__ == '__main__':
    window.mainloop()
    
