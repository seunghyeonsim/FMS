#! /usr/bin/env python3

import rospy
from kuka_rsi_ros_interface_msgs.srv import GetPose

def get_position_client():
    rospy.init_node('GetPosition_client')  # Initialize a ROS node with the name "GetPosition_client"
    rospy.wait_for_service('/get_position_values')  # Wait for the service to become available

    try:
        # Create a handle to the service
        get_position_service = rospy.ServiceProxy('/get_position_values', GetPose)

        # Call the service
        response = get_position_service()

        # Process the response
        pose = response.pose
        rospy.loginfo("Kuka x point is: %f", pose.x)
        rospy.loginfo("Kuka y point is: %f", pose.y)
        rospy.loginfo("Kuka z point is: %f", pose.z)
        rospy.loginfo("Kuka a point is: %f", pose.a)
        rospy.loginfo("Kuka b point is: %f", pose.b)
        rospy.loginfo("Kuka c point is: %f", pose.c)

    except rospy.ServiceException as e:
        rospy.logerr("Failed to call service /get_position_values: %s", str(e))

if __name__ == '__main__':
    get_position_client()
