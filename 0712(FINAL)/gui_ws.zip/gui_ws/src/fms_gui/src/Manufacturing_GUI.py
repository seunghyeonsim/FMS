import tkinter as tk
import rospy
from geometry_msgs.msg import Point
from std_srvs.srv import Trigger

root = tk.Tk()
rospy.init_node('gui_node')

def call_service():
    rospy.wait_for_service('/your_service_name')
    try:
        service_proxy = rospy.ServiceProxy('/your_service_name', Trigger)
        point_msg = Point(x=1.0, y=2.0, z=3.0)  # Create a sample Point message
        response = service_proxy(point_msg)
        result = response.success
        # Display the result in the GUI (e.g., update a label or text widget)
        result_label.config(text=f"Service Result: {result}")
    except rospy.ServiceException as e:
        print(f"Service call failed: {str(e)}")

frame1 = tk.Frame(root)
frame1.pack()

call_button = tk.Button(frame1, text="Call Service", command=call_service)
call_button.pack()

result_label = tk.Label(frame1, text="Service Result: ")
result_label.pack()

root.mainloop()

