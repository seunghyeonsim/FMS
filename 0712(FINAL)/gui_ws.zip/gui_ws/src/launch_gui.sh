#!/bin/bash

roslaunch fms_gui my_package_launch_file.launch

